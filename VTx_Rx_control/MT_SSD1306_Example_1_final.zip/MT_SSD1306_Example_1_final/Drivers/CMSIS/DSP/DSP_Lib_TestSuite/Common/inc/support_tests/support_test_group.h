#ifndef _SUPPORT_TEST_GROUP_H_
#define _SUPPORT_TEST_GROUP_H_

/*--------------------------------------------------------------------------------*/
/* Declare Test Groups */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(support_tests);

#endif /* _SUPPORT_TEST_GROUP_H_ */
