VTX_Test.ino - test/example and diagnostics Arduino sketch.
To turn detailed diagnostics, please uncomment SSWHD_DEBUG define in SoftwareSerialWithHalfDuplex.h and VTXCDEBUG define in VTXControl.h 
